#include <stdio.h>
#include <math.h>

double arcoseno_iperbolico(double x) {
    double risultato = x;  // Primo termine della serie
    double termine_2 = -(1.0/6.0) * pow(x, 3);
    risultato += termine_2;  // secondo termine
    double termine_3 = (3.0/40.0) * pow(x, 5);
    risultato += termine_3;  // terzo termine
    double termine_4 = -(5.0/112.0) * pow(x, 7);
    risultato += termine_4;  // quarto termine
    return risultato;
}

int main() {
    FILE *file = fopen("risultati.txt", "w");
    if (file == NULL) {
        printf("Impossibile aprire il file.\n");
        return 1;
    }
    
    double passo;
    
    printf("Inserisci il passo (ad esempio 0.01)\t");
    scanf("%lf", &passo);
    printf("\n\n");

    double x;
    double diff_massima = 0.0;
    printf(" x \t Taylor \t\t asinh(x) \t\t differenza\n");
    for (x = 0; x <= 4; x += passo) {
        double risultato = arcoseno_iperbolico(x);
        double asinh_risultato = asinh(x);
        double diff = fabs(risultato - asinh_risultato);
        if (diff > diff_massima) {
            diff_massima = diff;
        }
        fprintf(file, "%.2f %.6f %.6f %.6f\n", x, risultato, asinh_risultato, diff);
        printf("%.2f \t %.6f \t\t %.6f \t\t %.6f\n", x, risultato, asinh_risultato, diff);
    }

    fclose(file);
    printf("\nRisultati scritti correttamente nel file 'risultati.txt'.\n");
    printf("La differenza massima tra arcoseno iperbolico e asinh �: %lf\n", diff_massima);

    return 0;
}
